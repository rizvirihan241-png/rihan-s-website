RIHAN PORTFOLIO WEBSITE
=======================

FILES
- index.html  : page structure and content
- style.css   : colors, layout, responsive styling, and animations
- script.js   : mobile menu, active navigation, reveal effects, and email form

HOW TO RUN IN VS CODE
1. Extract the ZIP file into a folder.
2. Open VS Code.
3. Select File > Open Folder, then select the extracted "rihan_portfolio" folder.
4. Open index.html.
5. If you have the Live Server extension, right-click index.html and choose "Open with Live Server".
   Otherwise, open index.html directly in Chrome from File Explorer.
6. When changing code, save the file (Ctrl+S). Live Server normally refreshes the page automatically.

CUSTOMIZE BEFORE PUBLISHING
- Check the education details and add your graduation year if you want it shown.
- Replace any project description that does not accurately describe the final project you completed.
- The Python cafe project is presented as a project concept that should be polished and tested before publishing.
- Future project ideas are clearly marked as suggestions, not completed projects.
- Add your GitHub URL when you create or choose to share your GitHub profile.
- A resume button is not included yet because you said your resume PDF is not available.
- The contact form opens the visitor's default email app; it does not send mail directly from a server.
- Your phone and email are visible on the website. Remove them if you do not want them public.
- Google Fonts requires an internet connection; the site still uses a fallback font if unavailable.

PUBLISHING
You can publish this static website using GitHub Pages, Netlify, or another static hosting service.

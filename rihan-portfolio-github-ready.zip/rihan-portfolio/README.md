# Rihan — Portfolio Website

A responsive portfolio website built with plain HTML, CSS and JavaScript. No build tools or frameworks are required.

## Files
- `index.html` — website structure and content
- `style.css` — colors, layout, animations and responsive styles
- `script.js` — mobile menu, active navigation, current year and contact form

## Preview locally
1. Download and extract this folder.
2. Open `index.html` in Chrome, or open the folder in VS Code and use Live Server.

## Publish on GitHub Pages
1. Create a GitHub repository (for example, `rihan-portfolio`).
2. Upload all three files and this README to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then click **Save**.
6. Wait a few minutes and open the Pages URL GitHub provides.

## Personalize before publishing
- Replace `rihan@example.com` in `index.html` and `script.js` with your real email.
- Update social links to your actual LinkedIn, GitHub, Instagram and YouTube profiles.
- Add a real resume PDF to the repository and update the “Download Resume” links to its path (for example `assets/rihan-resume.pdf`).
- Check your education dates and project descriptions before publishing.

## Contact form note
The contact form opens the visitor's default email app using `mailto:`. It does not send messages to a server by itself. To receive submissions without the visitor's email app, connect a form service or backend.
